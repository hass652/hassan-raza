const ul = document.querySelector('ul'); //unordered list
const input = document.getElementById('item'); //input

//local storage
let itemsArray = localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')) : []; 

itemsArray.forEach(addTask);
function addTask (text) {
    const li = document.createElement('li');
    li.textContent  = text;
    ul.appendChild(li);
}
//add functionality
function add(){
    itemsArray.push(input.value);
    localStorage.setItem('items',JSON.stringify(itemsArray));
    addTask(input.value);
    input.value= '';
}

//delete functionality
function del(){
    localStorage.clear();
    ul.innerHTML = '' ;
    itemsArray = [];
}