// var movie =[

//     {
//         "id":0,
//         "title":"select a movie",
//         "description":"select a movie",
//         "director":"N/A",
//         "image1":"",
//     },

//     {
//         "id":1,
//         "title":"Goonies",
//         "description":"A group of children facing thier last days todether before a development paves over thier homes",
//         "director":"Ricahrd doner",
//         "image1":"movie1",
//     },

//     {
//         "id":2,
//         "title":"Tatanic",
//         "description":"A group of children facing thier last days todether before a development paves over thier homes",
//         "director":"Mat henry",
//         "image1":"movie2",
//     }
// ]
// for (let i=0; i<movie.length; i++){

//     document.getElementById("select1").innerHTML += `<option value="${i}">${movie[i].title} <option>`;
// }


//     function getdata(arg)
//     {
//         var select1=document.getElementById("select1").value;
//         if(arg !=0){
//             document.getElementById("image1").src= movie[arg].images;
//             document.getElementById("title").innerHTML= movie[arg].title;
//             document.getElementById("des1").innerHTML= movie[arg].description;
//             document.getElementById("director").innerHTML= movie[arg].director;
//         }
//     }
