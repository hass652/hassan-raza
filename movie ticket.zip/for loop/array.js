// let array =["ali","tofeeq"]
// for(i=0; i<array.length; i++){
//     document.getElementById("list").innerHTML +=  "<li>"+array[i]+"<li>" 
// }

// let NoOfPeople = prompt("Enter number of people")

// for (let j = 1; j <= NoOfPeople; j++) {

//     let array = []

//     let name = prompt(`enter ${j} person name:`)

//     array += name
// console.log(array)
//     for (let i = 0; i < array.length; i++) {
//         document.getElementById("list").innerHTML += `<li value="${i}">${array}</li>`
//         break;
//     }
// }